
public enum CardType {
	Special,
	Illuminati,
	Group
}
