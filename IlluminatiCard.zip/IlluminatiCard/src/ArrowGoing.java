
public enum ArrowGoing {
	in,
	out,
	none
}
