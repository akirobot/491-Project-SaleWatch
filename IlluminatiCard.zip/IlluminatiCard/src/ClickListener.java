
public interface ClickListener {

	public void onClick();
	
}
