import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class SpecialCard extends Card {

	public SpecialCard(float x, float y, int width, int height, String name,
			CardType type, BufferedImage face, BufferedImage back,
			boolean faceUP) {
		super(x, y, width, height, name, type, face, back, faceUP);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onClick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}

	

}
